package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.AdminLoginDTO;

public interface serviceLogin {
	public boolean registeration(AdminLoginDTO adminLoginDTO);
}
