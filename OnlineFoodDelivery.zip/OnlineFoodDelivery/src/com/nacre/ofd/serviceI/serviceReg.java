package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.AdminRegDTO;

public interface serviceReg {
	public boolean registeration(AdminRegDTO adminRegDTO);
}
