package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.CustomerLoginDTO;

public interface serviceCusLogin {
	public boolean registeration(CustomerLoginDTO customerLoginDTO);
}
