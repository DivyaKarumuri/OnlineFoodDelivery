package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.PaymentDto;

public interface PaymentService {

public abstract boolean payment(PaymentDto paymentDto);
	
}