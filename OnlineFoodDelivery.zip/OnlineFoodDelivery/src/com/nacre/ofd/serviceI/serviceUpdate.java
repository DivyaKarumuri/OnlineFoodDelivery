package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.UpdateItemsDTO;

public interface serviceUpdate {
	public boolean updateItem(UpdateItemsDTO updateItemsDTO);
}
