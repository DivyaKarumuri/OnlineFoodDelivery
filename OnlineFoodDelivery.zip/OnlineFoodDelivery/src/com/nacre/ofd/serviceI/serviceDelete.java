package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.DeleteItemsDTO;

public interface serviceDelete {
	public boolean deleteItem(DeleteItemsDTO deleteItemsDTO);
}
