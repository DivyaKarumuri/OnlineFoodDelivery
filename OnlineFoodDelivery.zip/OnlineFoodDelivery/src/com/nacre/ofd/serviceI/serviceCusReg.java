package com.nacre.ofd.serviceI;

import com.nacre.ofd.dto.CustomerRegDTO;

public interface serviceCusReg {
	public boolean registeration(CustomerRegDTO customerRegDTO);
}
