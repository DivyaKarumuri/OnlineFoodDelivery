package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.CustomerRegBO;

public interface cusRegDAOI {
	public int insertData(CustomerRegBO customerRegBO);
}
