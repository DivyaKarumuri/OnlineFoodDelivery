package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.*;

public interface PaymentIDao {
	public int insert(PaymentBo paymentbo);
}