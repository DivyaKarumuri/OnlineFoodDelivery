package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.AdminRegBO;

public interface registerDao {
	public int insertData(AdminRegBO adminRegBO);
}
