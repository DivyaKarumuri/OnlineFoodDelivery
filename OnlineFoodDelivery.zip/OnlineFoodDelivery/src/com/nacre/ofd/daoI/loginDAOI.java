package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.AdminLoginBO;

public interface loginDAOI {
	public int insertData(AdminLoginBO adminLoginBO);
}
