package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.CustomerLoginBO;

public interface loginCusDAOI {
	public int insertData(CustomerLoginBO customerLoginBO);
}
