package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.DeleteItemsBO;

public interface deleteDAOI {
	public int deleteData(DeleteItemsBO deleteItemsBO);
}
