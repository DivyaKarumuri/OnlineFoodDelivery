package com.nacre.ofd.daoI;

import com.nacre.ofd.bo.UpdateItemsBO;

public interface updateDAOI {
	public int updateData(UpdateItemsBO updateItemsBO);
}
